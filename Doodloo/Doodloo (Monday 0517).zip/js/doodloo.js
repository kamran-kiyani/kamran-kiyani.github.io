//////////////////////////////////////////////////////////////////////////////////////////////////////////

// connects built-in camera and reads output to take still picture

(function() {

  var streaming = false,
      video        = document.querySelector('#video'),
      canvas       = document.querySelector('#canvas'),
      startbutton  = document.querySelector('#startbutton'),
      width = 350,
      height = 0;

  navigator.getMedia = ( navigator.getUserMedia ||
                         navigator.webkitGetUserMedia ||
                         navigator.mozGetUserMedia ||
                         navigator.msGetUserMedia);

  navigator.getMedia(
    {
      video: true,
      audio: false
    },
    function(stream) {
      if (navigator.mozGetUserMedia) {
        video.mozSrcObject = stream;
      } else {
        var vendorURL = window.URL || window.webkitURL;
        video.src = vendorURL.createObjectURL(stream);
      }
      video.play();
    },
    function(err) {
      console.log("An error occured! " + err);
    }
  );

  video.addEventListener('canplay', function(ev){
    if (!streaming) {
      height = video.videoHeight / (video.videoWidth/width);
      video.setAttribute('width', width);
      video.setAttribute('height', height);
      canvas.setAttribute('width', width);
      canvas.setAttribute('height', height);
      streaming = true;
    }
  }, false);

  function takepicture() {
    canvas.width = width;
    canvas.height = height;
    canvas.getContext('2d').drawImage(video, 0, 0, width, height);
    var data = canvas.toDataURL('image/png');
  }

  startbutton.addEventListener('click', function(ev){
      takepicture();
    ev.preventDefault();
  }, false);

})();

//////////////////////////////////////////////////////////////////////////////////////////////////////////

// logic for averaging out the color of image taken with the camera

var canvasObj = document.getElementById('canvas');
var ctx=canvasObj.getContext("2d");

function reDraw(canvasObj) {

var rgb = { r: 0, g: 0, b: 0 }; // Set a base colour as a fallback for non-compliant browsers

ctx.drawImage(img, 0, 0);

ctx.putImageData(imgData,0,0);

}

// Define a new context for the output

var canvas2Obj = document.getElementById('canvas2');
var tmpCtx=canvas2Obj.getContext("2d");

function createImageData(w,h) {
  return this.tmpCtx.createImageData(w,h);
};

function drawAverage (canvas2Obj) {

var rgb = { r: 0, g: 0, b: 0 }; // Set a base colour as a fallback for non-compliant browsers

var imageData=ctx.getImageData(0 , 0, canvasObj.width, canvasObj.height);
var pixelCluster = 9;
var count = 0;
var output = createImageData(canvasObj.width, canvasObj.height);
var dst = output.data;


// Go through the destination image pixels

  for (var y = 0; y < imageData.length; y++) {
    var sy = y
    var dstOff = y * 4;
    // average out colors of every 9 pixels
    for (var i = 0; i < imgData.data.length; i += 4) {
          count++;
          rgb.r += imgData.data[i];
          rgb.g += imgData.data[i + 1];
          rgb.b += imgData.data[i + 2];

        // if count is a multiple of 9, or every 9 pixels
          if ((count % pixelCluster) == 0) {
            // floor the average values to give correct rgb values (ie: round number values)
            rgb.r = Math.floor(rgb.r / pixelCluster);
            rgb.g = Math.floor(rgb.g / pixelCluster);
            rgb.b = Math.floor(rgb.b / pixelCluster);        
          }
          
      }

      dst[dstOff] = rgb.r; // r
      dst[dstOff + 1] = rgb.g; // g
      dst[dstOff + 2] = rgb.b; // b
      // imgData.data[i+3] = 255;

  }

  tmpCtx.putImageData(imageData,0,0);

}

//activates the mean color filter ability 
filterbutton = document.querySelector('#filterbutton');
filterbutton.addEventListener('click', function() {
    window.location.href = '#' + drawAverage(canvas2Obj);
});
